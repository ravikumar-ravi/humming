<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Offer Rides</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <!-- css -->
    <link rel="stylesheet" href="css/offeraride.css" />
  </head>
  <body>
    <div class="container mt-5">
        <div class="card">
        <form action="" method="post">
            <div class="card-header px-5 py-4 border-0 bg-light">
                <h4 class="fw-bold mb-0">Update Ride</h4>
            </div>
    <?php 
        include('connection.php');

        $e = $_GET['id'];
        $showquery = "select * from provider where p_id={$e}";
        $showdata = mysqli_query($con,$showquery);

        $arrdata = mysqli_fetch_assoc($showdata);

        if (isset($_POST['submit'])){

            $idupdate = $_GET['id'];

            $date = $_POST['ride_date'];
            $pickup = $_POST['pickup'];
            $dropoff = $_POST['dropoff'];
            $vehicle = $_POST['vehicle'];
            $seat = $_POST['seat'];
            $time = $_POST['ride_time'];
            $email = $_SESSION['email'];
            $name = $_POST['name'];
            $cnumber = $_POST['cnumber'];
            $price= $_POST['price'];
            
            $query = " update provider set p_id='$idupdate', `email`='$email',`date`='$date',`pickup`='$pickup',`dropoff`='$dropoff',`vehicle`='$vehicle',`seat`='$seat',`time`='$time',`name`='$name',`c_number`='$cnumber',`price`='$price' where p_id=$idupdate ";

            $res=mysqli_query($con, $query);
            $_SESSION['seat'] = $seat;
            if($res){
            echo "<script type=\"text/javascript\">\n";
            echo "alert('You have successfully Updated Your Ride!');\n";
            echo "window.location = ('viewofferedride.php');\n";
            echo "</script>";
            }
        }
        
    ?>
    <div class="card-body px-5">
        <div id="ride_date_box" style="display:box" class="mb-3">
            <label for="ride_date">Ride Date:</label>
            <input type="date" id="ride_date"  value="<?php echo $arrdata['date']; ?>" name="ride_date" class="form-control">
        </div>
<!--  -->
        <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" name="name" id="name" value="<?php echo $arrdata['name']; ?>" class="form-control" required >
    </div>
 
    
    <div class="mb-3">
        <label for="pickup" class="form-label">Pickup Location</label>
        <input type="text" name="pickup" id="pickup" value="<?php echo $arrdata['pickup']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="dropoff" class="form-label">Dropoff Location</label>
        <input type="text" name="dropoff" id="dropoff" value="<?php echo $arrdata['dropoff']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="vehicle" class="form-label">Vehicle Name</label>
        <input type="text" name="vehicle" id="vehicle" value="<?php echo $arrdata['vehicle']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="cnumber" class="form-label">Vehicle number</label>
        <input type="text" name="cnumber" id="cnumber" value="<?php echo $arrdata['c_number']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="seat" class="form-label">Available Seat</label>
        <input type="number" name="seat" id="seat" value="<?php echo $arrdata['seat']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="ride_time" class="form-label" id="deparrtime">Depart Time</label>
        <input type="time" id="ride_time" value="<?php echo $arrdata['time']; ?>" name="ride_time" class="form-control" required>
    </div>

    <div class="mb-3">
    <label for="price" class="form-label" >Price</label>
        <input type="text" id="price" value="<?php echo $arrdata['price']; ?>" name="price" class="form-control" required>
    </div>

    <div class="card-footer text-end border-0 bg-light py-4 px-5 ">
        <button type="submit" name="submit" class="btn btn-secondary btn-rounded">Update Ride</button>
      </div>

    </div>
    </form>
    </div>
    </div>
  
    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>

