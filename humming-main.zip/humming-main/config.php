<?php

$conn = mysqli_connect('localhost','root','12345','humming') or die('connection failed');

?>