<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/about-ex.css">
    <title>About me</title>
</head>
<body>
    

<div class="container">
    <h1>Ravi </h1>
    <h2>Web Dev</h2>
    <div class="image">
        <img src="./assets/me2.png" alt="me">
    </div>
    <p>
    Here is a man with great respect for computers and its technology that "tell a story and testify to the richness of one of our most precious resources."</p>
    <a href="https://www.instagram.com/humming_dev/?hl=en" class="btn">Get In Touch</a>
</div>


</body>
</html>