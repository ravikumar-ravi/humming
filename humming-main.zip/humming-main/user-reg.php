
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reg.css">
    <title>Registration</title>
</head>
<body>
    </div>

      <div class="container">
        <div class="title">Registration</div>
        <div id="error"></div>
        <form action="registration.php" method="post" enctype="multipart/form-data">
        <div class="user-details">
        
        <div class="input-box">
          <span class="details">Name</span>
          <input type="text" name="name" required value="">
        </div>

        <div class="input-box">
          <span class="details">Email</span>
          <input type="email" name="email" required value="">
        </div>

        <div class="input-box">
          <span class="details">Password</span>
          <input type="password" name="password" required value="">
        </div>

        <div class="input-box">
          <span class="details">Date Of Birth</span>
          <input type="date" name="birthday" required value="">
        </div>

        <div class="input-box">
          <span class="details">Address</span>
          <input type="text" name="address" required value="">
        </div>

        <div class="input-box">
          <span class="details">City</span>
          <input type="text" name="city" required value=""> 
        </div>

        <div class="input-box">
          <span class="details">State</span>
          <input type="text" name="state" required value="">
        </div>

        <div class="input-box">
          <span class="details">Country</span>
          <input type="text" name="country" required value=""> 
        </div> 
        
          <div class="input-box">
          <span class="details">Mobile</span>
          <input type="tel" name="mobile" value="" required id="mob" maxlength="10">
        </div>
       
        
        <div class="input-box">
        <span class="details">Document</span>
          <select name="docid">  
            <option value="GovernmentId">Government ID</option> 
            <option value="pan">PAN
              </option>  
              <option value="aadhar">Aadhar
              </option>  
            <option value="Dl">Driving licence
              </option>  
            <option value="Ecard">Election Card
              </option> 
            </select>  
            <input type="text" name="document" required value="" minlength="5">
        </div>      
        </div>  

        <div class="button">
          <input type="submit" name="submit" value="Register">
        </div>

        </form>
      </div>  
</body>
</html>
