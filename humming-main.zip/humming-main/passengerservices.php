<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/dservices.css">
    <title>Driver Services</title>
</head>
<body>
    <h4>Rider Services.</h4>
    <div class="container">
    <div class="box">
        <h3>Find Ride</h3>
        <p>Enter your personal details before ordering a ride.</p>
        <a href="displayride.php"><button>click here</button></a>
        <span class="count">1</span>
    </div>
    <div class="box">
        <h3>Prev Rides</h3>
        <p>click below to view your previous rides.</p>
        <a href="confirmedride.php"><button>click here</button></a>
        <span class="count">2</span>
    </div>
</div>

</body>
</html>