<?php include 'nav.php'?>;
<!DOCTYPE html>
<html>
  <head>
    <title>Services</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" href="./css/services.css">
    
  </head>
<body> 

  <div class="container my-5">

  <!-- Offer rides -->
    <section>
      <div class="text-center mb-5 col-md-10 mx-auto">
        <h2 class="font-weight-bold display-4 text-capitalize">Our <span class="text-primary-color">Services</span></h2>
        <p class="mx-5">Humming provides vast services to make sure that the ride goes smooth. Check out the services listed below. </p>
      </div>
      <div class="row">
        <div class="col-md-4 my-4">
          <a href="#" class="text-dark">
            <div class="px-3 py-5">
              <span class="text-uppercase">Services</span>
              <h3 class="text-capitalize my-2 font-weight-600">Find about offering rides.</h3>
              <!-- <button class="btn my-4 px-4 py-2 rounded-pill text-white bg-primary-color">See More</button> -->
              <button class="btn my-4 px-4 py-2 rounded-pill text-white bg-primary-color" onclick="location.href='driverservices.php'" type="button">See More</button>
            </div>
          </a>
        </div>
        <div class="col-md-4 my-4">
          <a href="#" class="text-dark">
            <div class="px-3 py-5 bg-light rounded">
              <div class="text-center">
                <i class="fas fa-chart-area fa-3x mb-3"></i>
              </div>
              <div class="px-3 text-center pb-3">
                <h5 class="text-uppercase font-weight-600">Offer Ride</h5>
                <p class="font-weight-light my-3">The user he/she can offer a ride and before entering the offering details,user should enter the details of own.</p>
              </div>
            </div>
          </a>
        </div>
        <div class="col-md-4 my-4">
          <a href="#" class="text-dark">
            <div class="px-3 py-5 bg-primary-color text-white rounded">
              <div class="text-center">
                <i class="fas fa-chart-area fa-3x mb-3"></i>
              </div>
              <div class="px-3 text-center pb-3">
                <h5 class="text-uppercase font-weight-600">View Your Offered Rides</h5>
                <p class="font-weight-light my-3">The offered rides will be listed here and the user can also modify the offered ride.</p>
              </div>
            </div>
          </a>
        </div>
        <div class="row">
        <div class="col-md-4 my-4">
          <a href="#" class="text-dark">
            <div class="px-3 py-5">
              <span class="text-uppercase">Services</span>
              <h3 class="text-capitalize my-2 font-weight-600">Find about offered rides.</h3>
             
              <button class="btn my-4 px-4 py-2 rounded-pill text-white bg-primary-color" onclick="location.href='passengerservices.php'" type="button">See More</button>
            </div>
          </a>
        </div>
        <div class="col-md-4 my-4">
          <a href="#" class="text-dark">
            <div class="px-3 py-5 bg-light rounded">
              <div class="text-center">
                <i class="fas fa-chart-area fa-3x mb-3"></i>
              </div>
              <div class="px-3 text-center pb-3">
                <h5 class="text-uppercase font-weight-600">Offered Rides</h5>
                <p class="font-weight-light my-3">The list of offered rides will be listed here the user can enter their details to book the ride. </p>
              </div>
            </div>
          </a>
        </div>
        <div class="col-md-4 my-4">
          <a href="#" class="text-dark">
            <div class="px-3 py-5 bg-primary-color text-white rounded">
              <div class="text-center">
                <i class="fas fa-chart-area fa-3x mb-3"></i>
              </div>
              <div class="px-3 text-center pb-3">
                <h5 class="text-uppercase font-weight-600">View Accepted Rides</h5>
                <p class="font-weight-light my-3">The accepted rides /the user previous rides will be displayed in the tab.</p>
              </div>
            </div>
          </a>
        </div>
      </div>
    </section>

  </div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

