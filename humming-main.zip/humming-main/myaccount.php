
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Settings</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />

	<!-- css -->
	<link rel="stylesheet" href="css/myaccount.css">
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
  </head>
  <body>

<?php 
include 'connection.php';

$e =  $_SESSION['user_id'];
$sql = "SELECT * FROM `user_db` WHERE id={$e}";
$result = mysqli_query($con,$sql);

$num = mysqli_num_rows($result);

$row = mysqli_fetch_assoc($result);

?>


  <div class="container my-5">
  <div class="card">
    <form method="POST" action="myaccount-mod.php">
      <!-- Card header -->
      <div class="card-header py-4 px-5 bg-light border-0">
        <h4 class="mb-0 fw-bold">Settings</h4>
      </div>

      <!-- Card body -->
      <div class="card-body px-5">
        <!-- Account section -->
        <div class="row gx-xl-5">
          <div class="col-md-4">
            <h5>Account</h5>
            <p class="text-muted">Your account details.</p>
          </div>

          <div class="col-md-8">
            <div class="mb-3">
              <label for="exampleInput1" class="form-label"
                     >Full name</label
                >
              <input type="text" class="form-control" id="exampleInput1" style="max-width: 500px;" value="<?php echo $row['name']; ?>" disabled/>
            </div>

            <div class="mb-3">
              <label for="exampleInput2" class="form-label"
                     >Email address</label
                >
              <input type="email" class="form-control" id="exampleInput2" style="max-width: 500px; " value="<?php echo $row['email']; ?>" disabled/>
            </div>

            <div class="mb-3">
              <label for="exampleInput3" class="form-label"
                     >Phone number</label
                >
              <input type="tel" class="form-control" id="exampleInput3" style="max-width: 300px;" value="<?php echo $row['mobile']; ?>" disabled/>
            </div>

			<div class="mb-3">
              <label for="exampleInput4" class="form-label"
                     >Birthday</label
                >
              <input type="date" class="form-control" id="exampleInput4" style="max-width: 300px; " value="<?php echo $row['birthday']; ?>" disabled/>
            </div>

			<div class="mb-3">
              <label for="exampleInput5" class="form-label"
                     >Document</label
                >
              <input type="text" class="form-control" id="exampleInput" style="max-width: 300px; " value="<?php echo $row['doc']; ?>" disabled/>
            </div>
          </div>
        </div>

        <hr class="my-5" />

        <!-- Business address section -->
        <div class="row gx-xl-5">
          <div class="col-md-4">
            <h5>Business address</h5>
            <p class="text-muted">Residence | Permanent Address.</p>
          </div>

          <div class="col-md-8">
            <div class="mb-3">
              <label for="exampleInput6" class="form-label"
                     >Street address</label
                >
              <input type="text" class="form-control" id="exampleInput6" value="<?php echo $row['address']; ?>" disabled />
            </div>

            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label for="exampleInput7" class="form-label">City</label>
                  <input
                         type="text"
                         class="form-control"
                         id="exampleInput7"
                         value="<?php echo $row['city']; ?>"
                         disabled
                         />
                </div>
              </div>

              <div class="col-md-6">
                <label for="exampleInput8" class="form-label">State</label>
                <input
                         type="text"
                         class="form-control"
                         id="exampleInput8"
                         value="<?php echo $row['state']; ?>"
                         disabled
                         />
              </div>
            </div>

            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label for="exampleInput9" class="form-label"
                         >Country</label
                    >
                  <input
                         type="text"
                         class="form-control"
                         id="exampleInput9"
                         value="<?php echo $row['country']; ?>"
                         disabled
                         />
                </div>
              </div>
            </div>
          </div>
        </div>

        <hr class="my-5" />

        <!-- Password section -->
        <div class="row gx-xl-5">
          <div class="col-md-4">
            <h5>Password</h5>
            <p class="text-muted"> Your account password.</p>
          </div>

          <div class="col-md-8">
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label for="exampleInput11" class="form-label"
                         >Old password</label
                    >
                  <input
                         type="password"
                         class="form-control"
                         id="exampleInput11"
                        value=" <?php echo $row['password']; ?>"
                         disabled
                         />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Card footer -->
      <div class="card-footer text-end py-4 px-5 bg-light border-0">
        <!-- <button class="btn btn-link btn-rounded" data-ripple-color="primary"  onclick="window.location.href ='home.php'">Cancel</button> -->
        <button type="submit" class="btn btn-secondary btn-rounded" >
          Edit
        </button>
      </div>
    </form>
  </div>
</div>

    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>

