<!-- script -->

<?php

include 'config.php';
session_start();

if(isset($_POST['submit'])){

   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = mysqli_real_escape_string($conn, $_POST['password']);

   $select = mysqli_query($conn, "SELECT * FROM `user_db` WHERE email = '$email' AND password = '$pass'") or die('query failed');

   if(mysqli_num_rows($select) > 0){
      $row = mysqli_fetch_assoc($select);
      $_SESSION['user_id'] = $row['id'];
      $_SESSION['email'] = $email;

      header('location:home.php');
   }else{
	echo '<script>alert("Invalid username and password")</script>';
   }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/log.css" type="text/css">
    <title>Log-in</title>
</head>
<body>

<form action="" method="post">
<div class="wrapper">

	<div class="title">
		<p>Sign in</p>
	</div>
	<div class="form">
		<div class="input_field">
			<label>Email address</label>
			<input type="text" class="input" name="email">
		</div>
		<div class="input_field">
			<label>Password</label>
			<input type="password" class="input" name="password">
		</div>
		<div class="btn">
			<input type="submit" value="Sign in" class="sign_btn" name="submit">
		</div>
	</div>
	<div class="create_act">
		<p>New to Humming? <a href="./user-reg.php">Create an account.</a></p>
	</div>
	<div class="footer">
		<ul>
			<li><a href="terms.php">Terms</a></li>
			<li><a href="./contact.html">Contact Humming</a></li>
		</ul>
	</div> 
</div>	
</form>
</body>
</html>