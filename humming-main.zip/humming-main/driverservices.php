

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/dservices.css">
    <title>Driver Services</title>
</head>
<body>
    <h4>Driver Services.</h4>
    <div class="container">
    <div class="box">
        <h3>Offer Ride</h3>
        <p>Enter your personal details before offering a ride.</p>
        <a href="offeraride.php"><button>click here</button></a>
        <span class="count">1</span>
    </div>
    <div class="box">
        <h3>View Ride</h3>
        <p>View offered ride here,d etails can be modified here.</p>
        <a href="viewofferedride.php"><button>click here</button></a>
        <span class="count">2</span>
    </div>

</div>
</body>
</html>