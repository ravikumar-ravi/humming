<?php
    include('connection.php');
    $m = $_SESSION['email'];
    
    $check = " select * from provider where email= '$m' ";
    $r = mysqli_query($con,$check);
    $n = mysqli_num_rows($r);
                 
    if($n != "0"){
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Offer Rides</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <!-- css -->
    <link rel="stylesheet" href="css/viewofferride.css" />
  </head>
  <body style="background-color: hsl(0,0%,94%);">
    <div class="container my-5">
      <h4 class="fw-bold mb-0">Offered Ride</h4>
      <div class="shadow-4 rounded-5 overflow-hidden">
      <table class="table align-middle mb-0 bg-white">
            <thead class="bg-light">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Date of Ride</th>
                    <th>Pickup</th>
                    <th>Dropoff</th>
                    <th>Vehicle</th>
                    <th>Vehicle Number</th>
                    <th>Available Seat</th>
                    <th>Time(24hr)</th>
                    <th>Price</th>
                    <th colspan="2">Operation</th>
                </tr>
            </thead>
            <tbody>
            <?php
                    while($res = mysqli_fetch_assoc($r)){
                        ?>
                        <tr>
                        <td><?php echo $res['name']; ?> </td>
                        <td>
                        <span class="badge rounded-pill badge-info"><?php echo $res['email']; ?></span>
                        </td>
                        <td>
                        <span class="badge rounded-pill badge-danger"><?php echo $res['date']; ?></span>
                        </td>
                        <td><?php echo $res['pickup']; ?> </td>
                        <td><?php echo $res['dropoff']; ?> </td>
                        <td><?php echo $res['vehicle']; ?> </td>
                        <td><?php echo $res['c_number']; ?> </td>
                        <td>
                        <span class="badge badge-success rounded-pill"><?php echo $res['seat']; ?></span>
                        </td>
                        <td>
                        <span class="badge rounded-pill badge-warning"> <?php echo $res['time']; ?></span>
                        </td>
                        <td><?php echo $res['price']; ?> </td>
                        <td><a href="rideupdate.php?id=<?php echo $res['p_id']; ?>" data-toggle="tooltip" data-placement="top" title="Update"><i class="fa fa-edit" aria-hidden="true"></i></a></td>
                        <td><a href="ridedelete.php?id=<?php echo $res['p_id']; ?>" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                        </tr>
                        <?php
                }
            ?>
            </tbody>
        </table>
      </div>
    </div>

    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php
    }
    else{
        echo "<script type=\"text/javascript\">\n";
        echo "alert('OOPS...No Offered Ride!!');\n";
        echo "window.location = ('services.php');\n";
        echo "</script>";    
    }
?>
