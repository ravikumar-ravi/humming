
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Terms</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <!-- css -->
    <link rel="stylesheet" href="css/terms.css">
  </head>


  
  <body>
<!-- nav -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <!-- Dropdown -->
      <li class="nav-item dropdown">
        <a
          class="nav-link dropdown-toggle"
          href="#"
          id="navbarDropdownMenuLink"
          role="button"
          data-mdb-toggle="dropdown"
          aria-expanded="false"
        >
          Settings
        </a>
        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <li>
            <a class="dropdown-item" href="index.php">Home</a>
          </li>
          <li>
            <a class="dropdown-item" href="user-log.php">Login</a>
          </li>
          <li>
            <a class="dropdown-item" href="user-reg.php">Signup</a>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</nav>



    <br>
    <br>
    <br>
    <h6>Humming | Car Pooling Platform</h6>
    <br>

    <h1>Terms and Conditions.</h1>
    <br>
    <h4>PRIVACY</h4>
    <p>Usage of Services available on the Humming  platform is subject to Privacy Policy. By using Services You accept and agree to be bound and abide by the Privacy Policy. Humming  reserves the right to amend Privacy Policy from time to time. </p>
    <p>We only use Your information as described in the Privacy Policy. We view protection of users’ privacy as a very important community principle. We understand clearly that You and Your information is one of Our most important assets. We store and process Your information on computers that are protected by physical as well as technological security devices. We use third parties to verify and certify Our privacy principles.</p>
    <p>If You object to Your Information being transferred or used in this way, please do not use or access Humming  Platform Services.</p>

    <h4>COPYRIGHT COMPLAINTS AND COPYRIGHT AGENT</h4>
    <p>Humming  respects the intellectual property of others, and expects Users to do the same. If You believe, in good faith, that any materials on the Services infringe upon Your copyrights, please send the following information to Humming ’s 
     A description of the copyrighted work that You claim has been infringed, including specific location on the Services where the material You claim is infringed is located. Include enough information to allow Humming  to locate the material, and explain why You think an infringement has taken place;
     A description of the location where the original or an authorized copy of the copyrighted work exists – for example, the URL (Internet address) where it is posted or the name of the book in which it has been published;
    Your address, telephone number, and e-mail address;
    A statement by You that You have a good faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law;
    A statement by You, made under penalty of perjury, that the information in Your notice is accurate, and that You are the copyright owner or authorized to act on the copyright owner’s behalf; and
    An electronic or physical signature of the owner of the copyright or the person authorized to act on behalf of the owner of the copyright interest.
    </p>

    <h4>TERM AND TERMINATION</h4>
    <p>This Agreement is effective upon use of the Humming  Platform or the Services for new Users and upon the posting dates of any subsequent amendments to this Agreement for all current Users.
    You may terminate Your participation in the Services at any time, for any reason upon receipt by Us of Your written or email notice of termination.
    Either You or We may terminate Your participation in the Humming  Platform, for any or no reason, without explanation. Upon such termination, We may retain an archived copy of records We have about You as may be required by law. We maintain sole discretion to bar Your use of the Services in the future, for any or no reason. Even after Your participation in the Humming  Platform is terminated, this Agreement will remain in effect.
</p>

    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>

