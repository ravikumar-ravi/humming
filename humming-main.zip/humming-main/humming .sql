-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2022 at 03:52 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `humming`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'Bandit7564@');

-- --------------------------------------------------------

--
-- Table structure for table `confirmedride`
--

CREATE TABLE `confirmedride` (
  `c_id` int(255) NOT NULL,
  `email` varchar(40) NOT NULL,
  `driver_email` varchar(40) NOT NULL,
  `date` date NOT NULL,
  `pickup` varchar(40) NOT NULL,
  `dropoff` varchar(40) NOT NULL,
  `vehicle` varchar(40) NOT NULL,
  `rseat` int(10) NOT NULL,
  `time` time NOT NULL,
  `name` varchar(255) NOT NULL,
  `c_number` varchar(255) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `confirmedride`
--

INSERT INTO `confirmedride` (`c_id`, `email`, `driver_email`, `date`, `pickup`, `dropoff`, `vehicle`, `rseat`, `time`, `name`, `c_number`, `price`) VALUES
(60, 'akashs.business6@gmail.com', 'kirankiru314@gmail.com', '2022-08-28', 'vijayangar', 'kengeri', 'swift', 1, '10:00:00', '', '', 0),
(61, 'kirankiru314@gmail.com', 'loyewaj573@ulforex.com', '2022-08-28', 'goc sector', 'nadiad rail', 'duster', 1, '08:00:00', '', '', 0),
(62, 'akashs.business6@gmail.com', 'loyewaj573@ulforex.com', '2022-08-28', 'goc sector', 'nadiad rail', 'duster', 1, '08:00:00', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `id` int(255) NOT NULL,
  `name` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `num` text NOT NULL,
  `mail` varchar(40) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`id`, `name`, `gender`, `num`, `mail`, `address`) VALUES
(17, 'elliot alderson', 'M', '2147483647', 'useme.test12345@gmail.com', 'india'),
(21, 'akash', 'M', '8197275594', 'akashs.business6@gmail.com', 'mylasandra'),
(24, 'kiran', 'M', '9916942103', 'kirankiru314@gmail.com', 'gkw'),
(25, 'krutik patel', 'M', '7080901090', 'loyewaj573@ulforex.com', 'nadiad');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`) VALUES
(4, 'loyewaj573@ulforex.com'),
(5, 'akashs.business6@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `provider`
--

CREATE TABLE `provider` (
  `p_id` int(255) NOT NULL,
  `email` varchar(40) NOT NULL,
  `date` date NOT NULL,
  `pickup` varchar(40) NOT NULL,
  `dropoff` varchar(40) NOT NULL,
  `vehicle` varchar(40) NOT NULL,
  `seat` int(10) NOT NULL,
  `time` time NOT NULL,
  `name` varchar(255) NOT NULL,
  `c_number` varchar(255) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `provider`
--

INSERT INTO `provider` (`p_id`, `email`, `date`, `pickup`, `dropoff`, `vehicle`, `seat`, `time`, `name`, `c_number`, `price`) VALUES
(33, 'useme.test12345@gmail.com', '2022-08-13', 'vijayangar', 'kengeri', 'rolls royce ', 2, '15:11:00', 'elliot alderson', 'KA7CR50999', 1500),
(34, 'kirankiru314@gmail.com', '2022-08-28', 'vijayangar', 'kengeri', 'swift', 1, '10:00:00', 'kiran', 'KA7CR50999', 150),
(35, 'loyewaj573@ulforex.com', '2022-08-28', 'goc sector', 'nadiad rail', 'duster', 0, '08:00:00', 'krutik patel', 'KA7CR50992', 200),
(36, 'akashs.business6@gmail.com', '2022-08-24', 'kengeri', 'whitefield', 'duster', 2, '09:00:00', 'elliot alderson', 'KA07JB0008', 200);

-- --------------------------------------------------------

--
-- Table structure for table `user_db`
--

CREATE TABLE `user_db` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `birthday` date NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `mobile` text NOT NULL,
  `doc` text NOT NULL,
  `doc_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_db`
--

INSERT INTO `user_db` (`id`, `name`, `email`, `password`, `birthday`, `address`, `city`, `state`, `country`, `mobile`, `doc`, `doc_id`) VALUES
(21, 'Elliot', 'akashs.business6@gmail.com', 'bandit7564', '2001-06-20', 'channsandra', 'bangalore', 'karnataka', 'india', '9998887770', 'EIRPA1925S', 'pan'),
(22, 'kiran', 'kirankiru314@gmail.com', 'ninja400', '2001-08-15', 'vijaynagar', 'bangalore', 'karnataka', 'india', '9916942103', 'EIRPA1925A', 'pan'),
(23, 'krutik patel', 'loyewaj573@ulforex.com', 'bandit7564', '2001-06-28', 'nairobi soc', 'nadiad', 'gujrat', 'india', '7043536164', 'EIRPA1925B', 'pan'),
(24, 'eggsy', 'itsakashraj363@gmail.com', '123', '2000-05-29', 'channsandra', 'bangalore', 'karnataka', 'india', '7043536163', 'EIRPA1925J', 'pan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `confirmedride`
--
ALTER TABLE `confirmedride`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mail` (`mail`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `user_db`
--
ALTER TABLE `user_db`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `confirmedride`
--
ALTER TABLE `confirmedride`
  MODIFY `c_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `provider`
--
ALTER TABLE `provider`
  MODIFY `p_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `user_db`
--
ALTER TABLE `user_db`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
