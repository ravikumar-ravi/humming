<?php
include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Offer Rides</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <!-- css -->
    <link rel="stylesheet" href="css/admin-mod.css" />
  </head>
  <body>
  


<div class="container my-5">
<a href="admin-home.php" data-toggle="tooltip" data-placement="top" title="Back">
<i class="fa-solid fa-backward"></i></a>
    <h4 class="fw-bold mb-0">User Data</h4>
    <div class="shadow-4 rounded-5 overflow-hidden">
    <table  class="table align-middle mb-0 bg-white">
            <thead class="bg-light">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>DOB</th>
                    <th>Country</th>
                    <th>Mobile</th>
                    <th>Doc</th>
                    <th>Doc No</th>
                    <th colspan="2">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php


            $sql = "SELECT * FROM `user_db`";
            $res = mysqli_query($con,$sql);

            $num = mysqli_num_rows($res);

            while($row = mysqli_fetch_assoc($res)){
                if($num>0){
            //    $row = mysqli_fetch_assoc($res) ;
            //    echo var_dump($row);

            ?>
                <tr>
                    <td><?php echo $row['name']; ?> </td>
                    <td>
                    <span class="badge rounded-pill badge-primary"> <?php echo $row['email']; ?></span>
                    </td>
                    <td>
                    <span class="badge rounded-pill badge-danger"><?php echo $row['password']; ?> </span>
                    </td>
                    <td><?php echo $row['birthday']; ?> </td>
                    <td>
                    <span> <?php echo $row['country']; ?> </span>
                    </td>
                    <td>
                    <span> <?php echo $row['mobile']; ?> </span>
                    </td>
                    <td><?php echo $row['doc_id']; ?> </td>
                    <td>
                    <span class="badge rounded-pill badge-info"> <?php echo $row['doc']; ?></span>
                    </td>
                   <td>
                    <a href="userupdate.php?id=<?php echo $row['id']; ?>" data-toggle="tooltip" data-placement="top" title="Update">
                    <i class="fa-solid fa-pen-to-square"  href="#" ></i></a>
                   </td>
                   <td>
                   <a href="userdelete.php?id=<?php echo $row['id']; ?>" data-toggle="tooltip" data-placement="top" title="Delete">
                   <i class="fa-solid fa-circle-minus"></i>
                   </a>
                   </td>
                </tr>

                <?php
                }
                }
                ?>
            </tbody>
        </table>
  </div>
  </div>
    
    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>

