<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>User Update</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
  </head>
  <body>
  <div class="container mt-5">
        <div class="card">
        <form action="" method="post">
            <div class="card-header px-5 py-4 border-0 bg-light">
                <h4 class="fw-bold mb-0">Update User Data</h4>
            </div>
  <?php 
        require('connection.php');

        $e = $_GET['id'];
        $showquery = "select * from user_db where id={$e}";
        $showdata = mysqli_query($con,$showquery);

        $arrdata = mysqli_fetch_assoc($showdata);

        if (isset($_POST['submit'])){

          
            $id= $_GET['id'];

            $name = $_POST['name'];
            $pass = $_POST['password'];
            $dob = $_POST['birthday'];
            $address = $_POST['address'];
            $city = $_POST['city'];
            $state = $_POST['state'];
            $country = $_POST['country'];
            $mob = $_POST['mobile'];
            
            $query = " update user_db set id='$id',`name`='$name',`password`='$pass',`birthday`='$dob', `address`='$address', `city`='$city',`state`='$state', `country`='$country',`mobile`='$mob' where id=$id ";
    
            $res=mysqli_query($con, $query);
            if($res){
            echo "<script type=\"text/javascript\">\n";
            echo "alert('successfully Updated!');\n";
            header("Location:admin-mod.php");
            echo "</script>";
            }
        }
        
    ?>
    <div class="card-body px-5">
<!--  -->
        <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" name="name" id="name" value="<?php echo $arrdata['name']; ?>" class="form-control" required >
    </div>
 
    <div class="mb-3">
        <label for="pass" class="form-label">Password</label>
        <input type="text" name="password" value="<?php echo $arrdata['password']; ?>" class="form-control" required >
    </div>


    <div class="mb-3">
    <label for="birthday" class="form-label">DOB</label>
        <input type="date" name="birthday"  value="<?php echo $arrdata['birthday']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="address" class="form-label">Address</label>
        <input type="text" name="address" value="<?php echo $arrdata['address']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="city" class="form-label">City</label>
        <input type="text" name="city" value="<?php echo $arrdata['city']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="" class="form-label">State</label>
        <input type="text" name="state" value="<?php echo $arrdata['state']; ?>" class="form-control" required >
    </div>

    <div class="mb-3">
    <label for="country" class="form-label" >Country</label>
        <input type="text" value="<?php echo $arrdata['country']; ?>" name="country" class="form-control" required>
    </div>

    <div class="mb-3">
    <label for="" class="form-label" >Mobile</label>
        <input type="number" value="<?php echo $arrdata['mobile']; ?>" name="mobile" class="form-control" required>
    </div>

    <div class="card-footer text-end border-0 bg-light py-4 px-5 ">
        <button type="submit" name="submit" class="btn btn-secondary btn-rounded">Update</button>
      </div>

      </div>
    </form>
    </div>
    </div>
  
    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>

















