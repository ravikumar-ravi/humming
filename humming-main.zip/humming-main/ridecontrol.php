<?php 

include('connection.php');

$date = $_POST['ride_date'];
$pickup = $_POST['pickup'];
$dropoff = $_POST['dropoff'];
$vehicle = $_POST['vehicle'];
$seat = $_POST['seat'];
$time = $_POST['ride_time'];
$email = $_SESSION['email'];
$name = $_POST['name'];
$cnumber = $_POST['cnumber'];
$price= $_POST['price'];

$reg= " insert into provider(email, date, pickup, dropoff, vehicle, seat, time, name, c_number, price) values ('$email','$date', '$pickup', '$dropoff', '$vehicle', '$seat', '$time','$name','$cnumber','$price')";
mysqli_query($con, $reg);
echo "<script type=\"text/javascript\">\n";
echo "alert('You have successfully offered a Ride!');\n";
echo "window.location = ('services.php');\n";
echo "</script>";

?>