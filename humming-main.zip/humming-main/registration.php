<?php

include "connection.php";

$name     = $_POST['name'];
$email    = $_POST['email'];
$password = $_POST['password'];
$dob = $_POST['birthday'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$country= $_POST['country'];
$mob = $_POST['mobile'];
$doc = $_POST['document'];
$docid = $_POST['docid'];

$s = "SELECT * FROM user_db WHERE email = '$email'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);


// document validation
$d = "SELECT * FROM user_db WHERE doc = '$doc'";

$result2 = mysqli_query($con,$d);

$num2 = mysqli_num_rows($result2);


if($num== 1 || $num2==1){

    echo '<script>alert("User ID already exist! Enter new email|document.")</script>';
    echo "window.location = ('user-reg.php')";
}

else{ 

    $reg = "INSERT INTO user_db(name, email, password, birthday,address, city, state, country, mobile, doc, doc_id) values('$name','$email','$password','$dob','$address','$city','$state','$country','$mob','$doc','$docid')";
    mysqli_query($con,$reg);
    echo "<script type=\"text/javascript\">\n";
    echo "alert('Successfully registered!!');\n";
    echo "window.location = ('user-log.php');\n";
    echo "</script>";    
}

?>