<?php
include('connection.php');

$e = $_GET['id'];

$deletequery = " delete from user_db where id=$e ";
$query = mysqli_query($con,$deletequery);

if($query){
echo '<script>alert("User deleted successfully")</script>';
echo "<script type=\"text/javascript\">\n";
echo "window.location = ('admin-mod.php');\n";
echo "</script>";
}

?>