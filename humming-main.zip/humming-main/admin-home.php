<?php
include "connection.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="css/admin-home.css">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title>Admin Panel</title> 
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="assets/logo2.png" alt="">
            </div>

            <span class="logo_name">Humming</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="#">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                
                <li><a href="admin-mod.php">
                    <i class="uil uil-edit"></i>
                    <span class="link-name">Modify</span>
                </a></li>

                <li><a href="driverdisplay.php">
                    <i class="uil uil-car"></i>
                    <span class="link-name">Driver</span>
                </a></li>
                
                <li><a href="riderdisplay.php">
                    <i class="uil uil-user"></i>
                    <span class="link-name">Rider</span>
                </a></li>
               
            </ul>
            
            <!-- below bar -->
            <ul class="logout-mode">
                <li><a href="logout.php">
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a></li>

                <li class="mode">
                    <a href="#">
                        <i class="uil uil-moon"></i>
                    <span class="link-name">Dark Mode</span>
                </a>

                <div class="mode-toggle">
                  <span class="switch"></span>
                </div>
            </li>
            </ul>
        </div>
    </nav>

    <section class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>

            <!--<img src="images/profile.jpg" alt="">-->
        </div>

        <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="uil uil-tachometer-fast-alt"></i>
                    <span class="text">Dashboard</span>
                </div>

                <div class="boxes">
                    <div class="box box1">
                        <i class="uil uil-thumbs-up"></i>
                        <span class="text">Total Users</span>

                        <!-- total users -->
                        <?php
                        $dash_query = "SELECT * FROM user_db";
                        $dash_query_run = mysqli_query($con,$dash_query);
                        
                        
                        if($user_total = mysqli_num_rows($dash_query_run)){
                            echo '<span class="number">'.$user_total.'</span>';
                        }
                        else{
                            echo '<h4> No data <h4>';
                        }
                        ?> 

                        <!-- total drivers -->
                    </div>
                    <div class="box box2">
                        <i class="uil uil-comments"></i>
                        <span class="text">Total Drivers</span>
                        <?php
                        $dash_query = "SELECT * FROM provider";
                        $dash_query_run = mysqli_query($con,$dash_query);
                        
                        
                        if($driver_total = mysqli_num_rows($dash_query_run)){

                            echo '<span class="number">'.$driver_total.'</span>';

                        }
                        else{
                            echo '<h4> No data <h4>';
                        }
                        ?>



                    </div>
                    <div class="box box3">
                        <i class="uil uil-share"></i>
                        <span class="text">Total Rides</span>
                        <!-- total rides -->

                        <?php
                        $dash_query = "SELECT * FROM confirmedride ";
                        $dash_query_run = mysqli_query($con,$dash_query);
                        
                                
                        if($ride_total = mysqli_num_rows($dash_query_run)){

                            echo '<span class="number">'.$ride_total.'</span>';
        
                        }
                        else{
                            echo '<h4> No data <h4>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="js/script.js"></script>
</body>
</html>