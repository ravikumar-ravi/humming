<?php
session_start();
$con = mysqli_connect('localhost','root','12345', 'humming');
?>