<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Rider Details</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <link rel="stylesheet" type="text/css" href="style/offeraride.css">
  </head>
  <body style="background-color: hsl(0,0%,95%);">
    
    <div class="container mt-5">
        <div class="card">

        <form action="pdetails.php" method="post">
        <div class="card-header px-5 py-4 border-0 bg-light">
            <h4 class="fw-bold mb-0">Rider Details</h4>
        </div>

        <!-- card body -->
        <div class="card-body px-5">
        <div class="mb-3">
        <label class="form-label">Name: </label>
        <input type="text" name="name" id="name" value="" class="form-control" placeholder="Your Name" required >
    </div>
    <div class="mb-3">
        <label class="form-label">Gender: </label>
        <input  type="radio" name="gender" id = "Male" value="M"  checked required> Male
        <input  type="radio" name="gender" id ="Female" value="F" required > Female
    </div>
    <div class="mb-3">
        <label class="form-label">Mobile No.: </label>
        <input type="tel" name="num" id="num" value="" class="form-control" placeholder="Your Number" required maxlength="10">
    </div>
    <div class="mb-3">
        <label class="form-label">E-mail: </label>
        <input type="text" name="mail" id="mail" value="" class="form-control" placeholder="Your E-mail" required >
    </div>

    <div class="form-outline">
        <label class="form-label">Address: </label>
        <textarea class="form-control" id="address" name="address" cols="20" rows="3" placeholder="Your Address"></textarea>
    </div>
        </div>
        <div class="card-footer border-0 bg-light px-5 py-4 text-end">
        <button type="submit" class="btn btn-secondary btn-rounded">Submit</button>
      </div>
        </form>
        </div>
    </div>



    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>

