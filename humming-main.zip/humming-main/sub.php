<?php
require 'connection.php';


if(isset($_POST['submit'])){

    $userEmail = $_POST['email'];
    if(filter_var($userEmail,FILTER_VALIDATE_EMAIL)){
      $subject = "Thanks for subscribing our newsletter";
      $message = "Thanks for subscribing our newsletter. You'll recieve latest news and updates about humming." ;
      $sender = "FROM: demo3837@gmail.com"; 
      if(mail($userEmail, $subject,$message,$sender)){
        echo '<script>alert("Thanks for subscribing.")';
        echo "window.location = ('home.php');";
        echo '</script>'; 
        $userEmail ="";
      }else{
        echo '<script>alert("Failed while sending your email!.")';
        echo "window.location = ('home.php');"; 
        echo '</script>'; 
      }
    }
    else
    {
        echo '<script>alert("Email ID is invalid.")';
        echo "window.location = ('home.php');"; 
        echo '</script>'; 
    }
}


$email = $_POST['email'];

$s = "SELECT * FROM newsletter WHERE email = '$email'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);

// store in database
if($num== 1){

  echo '<script>alert("Email already is taken")</script>';
}
else{ 

  echo '<script>alert("Thanks for subscribing!")</script>';
  $reg = "INSERT INTO newsletter(email) values('$email')";
  mysqli_query($con,$reg);
}


?>


