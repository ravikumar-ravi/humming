<?php
include('connection.php');

$m = $_SESSION['email'];

$check = " select * from details where mail= '$m' ";
$res = mysqli_query($con,$check);
$n = mysqli_num_rows($res);
 
if($n == "0"){
    echo "<script type=\"text/javascript\">\n";
    echo "alert('Please Fill Your Details First.');\n";
    echo "window.location = ('driver.php');\n";
    echo "</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Offer Rides</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <!-- css -->
    <link rel="stylesheet" href="css/offeraride.css" />
  </head>
  <body>
  <div class="container mt-5">
    <div class="card">
        <div class="card-header px-5 py-4 border-0 bg-light">
        <h4 class="fw-bold mb-0">Offer A Ride</h4>   
        </div>

        <div class="card-body px-5">
            <!--card body -->
        
            <form action="ridecontrol.php" method="post">
        <!-- Ride Details -->
            <div class="row">
            <div class="col-md-4">
            <h5>Ride Details</h5>
            <p class="text-muted">Enter your pickup date,location and dropoff location perfectly to avoid confusion.</p>
            </div>
            
            <div class="col-md-8">
            <div class="mb-3">
             <div id="ride_date_box" style="display:box">
            <label for="ride_date">Ride date:</label>
            <input type="date" id="ride_date" name="ride_date" class="form-control" style="max-width: 500px;">
            </div>
            </div>

            <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" name="name" id="name" value="" class="form-control" required style="max-width: 650px;">
            </div>
    
             <div class="mb-3">
             <label for="pickup" class="form-label">Pickup location</label>
            <input type="text" name="pickup" id="pickup" value="" class="form-control" required style="max-width: 650px;">
            </div>

            <div class="mb-3">
            <label for="dropoff" class="form-label">Dropoff Location</label>
            <input type="text" name="dropoff" id="dropoff" value="" class="form-control" required style="max-width: 650px;">
            </div>

            </div>
            </div>
            <hr class="my-5"/>
            
            <!-- Vehicle details -->
            <div class="row">
            <div class="col-md-4">
            <h5>Vehicle details</h5>
            <p class="text-muted">Enter your vehical details properly as it will be helpful to identify.</p>
            </div>
            <div class="col-md-8">

            <div class="mb-3">
            <label for="vehicle" class="form-label">Vehicle name</label>
            <input type="text" name="vehicle" id="vehicle" value="" class="form-control" required style="max-width: 500px;">
            </div>

            <div class="mb-3">
            <label for="cnumber" class="form-label">Vehicle number</label>
            <input type="text" name="cnumber" id="cnumber" value="" class="form-control" required style="max-width: 500px;">
            </div>

             <div class="mb-3">
            <label for="seat" class="form-label">Available Seats</label>
            <input type="number" name="seat" id="seat" value="" class="form-control" required style="max-width: 300px;">
            </div>

            <div class="mb-3">
            <label id="deparrtime" class="form-label">Depart Time</label>
            <input type="time" id="ride_time" name="ride_time" class="form-control" required style="max-width: 300px;">
             </div>

             <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="text" name="price" id="price" value="" class="form-control" required style="max-width: 500px;">
            </div>

            </div>
            </div>
            <!-- <hr class="my-5"/> -->
        </div>
        <!-- card footer -->
        <div class="card-footer border-0 bg-light py-4 px-5 text-end">
        <button type="submit" class="btn btn-secondary btn-rounded">Offer Ride</button>
        </div>
        </form>
    </div>
</div>

    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>

