
<?php
include('connection.php');

$p = $_SESSION['email'];

$check = " select * from details where mail= '$p' ";
$res = mysqli_query($con,$check);
$s = mysqli_num_rows($res);
 
if($s == "0"){
    echo "<script type=\"text/javascript\">\n";
    echo "alert('Please Fill Your Details First.');\n";
    echo "window.location = ('passenger.php');\n";
    echo "</script>";
}


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Find A Ride</title>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <!-- css -->
    <link rel="stylesheet" href="css/offeraride.css" />
  </head>
  <body  style="background-color: hsl(0,0%,94%);">

  <div class="container my-5">
    <h4 class="fw-bold mb-0">Find Rides</h4>
    <div class="shadow-4 rounded-5 overflow-hidden">
    <table  class="table align-middle mb-0 bg-white">
            <thead class="bg-light">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Date of Ride</th>
                    <th>Pickup</th>
                    <th>Dropoff</th>
                    <th>Vehicle</th>
                    <th>Vehicle Number</th>
                    <th>Available Seat</th>
                    <th>Time(24hr)</th>
                    <th>Price</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php
                $cdate = date("y-m-d");
                $cdate1 = strtotime($cdate);
                $selectquery = " select * from provider where seat>0";
                $query = mysqli_query($con,$selectquery);

                $nums = mysqli_num_rows($query);
                while($res = mysqli_fetch_assoc($query)){
                    $date1 = strtotime($res['date']);
                    if (($date1)>=($cdate1)){
                        if(($res['email']) != ($p)){
            ?>    
                <tr>
                    <td><?php echo $res['name']; ?> </td>
                    <td>
                    <span class="badge rounded-pill badge-info"> <?php echo $res['email']; ?></span>
                       </td>
                    <td>
                        <span class="badge rounded-pill badge-danger"><?php echo $res['date']; ?> </span>
                    </td>
                    <td><?php echo $res['pickup']; ?> </td>
                    <td><?php echo $res['dropoff']; ?> </td>
                    <td><?php echo $res['vehicle']; ?> </td>
                    <td><?php echo $res['c_number']; ?> </td>
                    <td>
                    <span class="badge rounded-pill badge-success"> <?php echo $res['seat']; ?> </span>
                       </td>
                    <td>
                    <span class="badge rounded-pill badge-warning"> <?php echo $res['time']; ?> </span>
                    </td>
                    <td><?php echo $res['price']; ?> </td>
                    <td><button type="submit" class="btn btn-light"><a href="seat.php?id=<?php echo $res['p_id']; ?>">Select Ride</button></td>
                </tr>
            <?php
                }}}
            ?>
            </tbody>
        </table>
  </div>
  </div>
    
  
    <!-- MDB -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>

